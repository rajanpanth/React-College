let EventHandling = () => {
    let handleIncrement = (event) => {
        console.log("increment Button clicked")
        event.target.style.backgroundColor = "red"
    }
    return (
        <div>
            <h1>Event Handling Test</h1>
            <button onClick={handleIncrement} >
                Increment
            </button>
            <button onClick={
                () => {
                    console.log("decrement clicked")
                    console.log(event.target)
                }
            }>
                Decrement
            </button>

        </div>
    )
}
export default EventHandling