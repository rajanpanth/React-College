import { useState } from "react";
import CustomButton from "./Button";

let DaySix = () =>{
    let[count, setCount] = useState(0);
let[isLoggedin, setLoggedin] = useState(true);
return(
    <div>
        <h5>Count: {count}</h5>
        <button onClick={()=>setCount(count + 1)}>Increase</button>
        {count % 2 == 0 ? <h6>is Even</h6> : <h6>Is odd</h6>}

        {
        isLoggedin ? <CustomButton title = {"Logout"} onClickCustomButton={()=>setLoggedin(false)}></CustomButton> : <CustomButton title={"Login"} onClickCustomButton={()=>setLoggedin(true)}> </CustomButton>
        }
    </div>
)
}


export default DaySix 