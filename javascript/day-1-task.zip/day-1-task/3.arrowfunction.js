// Write an arrow function greet that takes a name and returns "Hello, !". Test it with your name.
let name = "Rajan"
greeting = () =>{
console.log(`Hello!, ${name}`)
}
greeting();