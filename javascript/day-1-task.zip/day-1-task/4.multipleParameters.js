// Write an arrow function multiply that takes two numbers and returns their product. Log the result for 5 and 6.

product = (a,b) =>{
console.log( a*b);
}
product(2,3);