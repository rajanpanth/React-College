// Create an array [10, 20, 30, 40]. Destructure the first two elements into variables and log them.

let arr = [10, 20, 30, 40];
let [a,b,c,d] = arr
console.log(a,b,c,d)