//Create two variables, firstName and lastName, and combine them into a greeting message using template literals. Log the message.
let firstName = "Rajan";
let lastName = "Pantha";
let greeting = `Goodmorning, It's me ${firstName}  ${lastName}`
console.log(greeting)

